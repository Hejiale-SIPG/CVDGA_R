library(randomForest)
library(pROC)
library(party)
library(caret)
library(dplyr)
library(umap)
library("FactoMineR")

FeaSel<-read.csv("feaSel_protein_20200606_MIX.csv",stringsAsFactors = F, row.names = 1)
promart <- read.csv("all_column_20200531_MIX.csv", stringsAsFactors = F, row.names = 1)
sample_lable <- read.csv("sample_labelFZ.csv", stringsAsFactors = F, row.names = 1)
promart_rowname<-row.names(promart)
promart_colname<-names(promart)
# promart[c(207:538),]<- data.frame(sapply(promart[c(207:538),],scale))

# promart<-data.frame(apply(promart,2,scale))

# promart_2<-preProcess(promart,method = c("range"))
# promart<-predict(promart_2,promart)
row.names(promart)<-promart_rowname
names(promart)<-promart_colname

names_promat <- row.names(promart)
promart_1 <- data.frame(matrix(NA, ncol=ncol(promart), nrow=nrow(FeaSel)))
for (i in 1:nrow(FeaSel)) {
  protSel <- FeaSel$x[i]
  selind <- vector()
  selind <- promart[row.names(promart)==protSel,]
  promart_1[i,] <- selind
}
row.names(promart_1) <- FeaSel$x
names(promart_1) <- names(promart)
names_promat_1 <- row.names(promart_1)
t_promat <- data.frame(t(promart_1))
names(t_promat) <- names_promat_1
t_promatNoQC <- t_promat[!grepl("QC",row.names(t_promat)),]

info <- data.frame(matrix(0,nrow = nrow(t_promatNoQC), ncol = 3))
row.names(info) <- row.names(t_promatNoQC)
names(info) <- c("typeLabel", "dayLabel","patient_id")
infoNoQC <- info

dayLabel <- typeLabel <- patientLabel <- vector()
for(j in 1:nrow(infoNoQC)) {
  samN <- unlist(strsplit(unlist(strsplit(row.names(infoNoQC)[j],"\\."))[1],"_"))[5]
  typeLabel[j] <- sample_lable[sample_lable$sample_N == samN,"clinical"]
  dayLabel[j] <- sample_lable[sample_lable$sample_N==samN,"label"]
  patientLabel[j] <- sample_lable[sample_lable$sample_N==samN,"PatientID_2"]
  infoNoQC[j, ] <- c(typeLabel[j],dayLabel[j],patientLabel[j])
  print(j)
}

fin_matirx <- data.frame(infoNoQC, t_promatNoQC)
names(fin_matirx) <- c(names(infoNoQC),names(t_promatNoQC))
fin_matirx <- fin_matirx[fin_matirx$dayLabel==1&fin_matirx$typeLabel!="Healthy"&fin_matirx$typeLabel!="non-COVID",]

 # final_matirx_scale_1<-data.frame(apply(fin_matirx[4:28],1,scale))
 # fin_matirx<-data.frame(fin_matirx[,1:3],t(final_matirx_scale_1))

 fin_matirx[,4:28]<-data.frame(apply(fin_matirx[,4:28],2,scale))
 names(fin_matirx) <- c(names(infoNoQC),names(t_promatNoQC))
 fin_matirx_d <- fin_matirx



# bulid a model
allcc_m <- 0
TesACC_yixiao_m<-0
rfAll<-list()
for(i in 1:100){
Folds<-createFolds(fin_matirx$typeLabel,10)
fin_matirx$typeLabel <- as.factor(fin_matirx$typeLabel)
for(m in 1:length(Folds)){
  TrainInd<-(1:nrow(fin_matirx))[-unlist(Folds[m])]
  ValInd<-(1:nrow(fin_matirx))[unlist(Folds[m])]
  rf1<-randomForest(x=as.matrix(fin_matirx[TrainInd,4:ncol(fin_matirx)]), y=fin_matirx$typeLabel[TrainInd],ntree=5000,nodesize=1)
  confMat<-(rf1$confusion)
  TrACC<-(confMat[1,1]+confMat[2,2])/sum(confMat[1,1]+confMat[2,2]+confMat[2,1]+confMat[1,2])
  predictVal <- predict(rf1, fin_matirx[ValInd,4:ncol(fin_matirx)],type = "prob")[,1]
  predictLabel<-as.numeric(predictVal<0.5)+1
  ValACC<-sum(predictLabel==as.numeric(fin_matirx$typeLabel[ValInd]))/length(predictLabel)#0,1; 1,2
  
   # fin_matirx_yx_all$typeLabel<-as.factor(fin_matirx_yx_all$typeLabel)
   # predictVal <- predict(rf1, fin_matirx_yx_all[,4:ncol(fin_matirx_yx_all)],type = "prob")[,1]
   # predictLabel<-as.numeric(predictVal<0.5)+1
   # TesACC_yixiao<-sum(predictLabel==as.numeric(fin_matirx_yx_all$typeLabel))/length(predictLabel)
  # 
   # fin_matirx_markus_all$severity<-as.factor(fin_matirx_markus_all$severity)
   # predictVal_markus <- predict(rf1, fin_matirx_markus_all[,3:ncol(fin_matirx_markus_all)],type = "prob")[,1]
   # predictLabel_markus<-as.numeric(predictVal_markus<0.5)+1
   # TesACC_makrus<-sum(predictLabel_markus==as.numeric(fin_matirx_markus_all$severity))/length(predictLabel_markus)
  # 
  allcc<-TrACC
  if(allcc>allcc_m&ValACC>0.8){

    allcc_m<-allcc
    TrACC_m<-TrACC
    ValACC_m<-ValACC
    rfAll<-rf1
    print(paste(TrACC_m,ValACC_m,allcc_m))
  }
}
print(i)
}
># load yixiao's data
promat_yixiao <- read.csv("all_column_20200531_yixiao_MIX.csv", stringsAsFactors = F, row.names = 1)
promat_yixiao<-promat_yixiao[apply(is.na(promat_yixiao),1,sum)!=ncol(promat_yixiao),]
names_yixiao<-row.names(promat_yixiao)
# promat_yixiao[175:1059,]<-2^promat_yixiao[175:1059,]
# promat_yixiao[c(175:1059),]<-data.frame(sapply(promat_yixiao[c(42:116,175:1059),],scale))
# promat_yixiao<-data.frame(apply(promat_yixiao,2,scale))
# promat_yixiao<-normalizeBetweenArrays(promat_yixiao,method = scale)
# promart_yixiao_2<-preProcess(promat_yixiao,method = c("range"))
# promat_yixiao<-predict(promart_yixiao_2,promat_yixiao)
row.names(promat_yixiao)<-names_yixiao
classDefinitions_yixiao <- read.csv("PatientMSID_noName_FZ20200329v3 _1.csv", stringsAsFactors = F, row.names = 1)
classDefinitions_yixiao <- classDefinitions_yixiao[,c(4,5,20)]
feature <- read.csv("feaSel_protein_20200606_MIX.csv", stringsAsFactors = F,row.names = 1)
# identical(colnames(promat_yixiao), classDefinitions_yixiao$MSID)

df_ratio_yixiao <- data.frame(matrix(NA,nrow = nrow(feature), ncol = ncol(promat_yixiao)))
for(i in 1:nrow(feature)){
  protSel <- feature$x[i]
  selInd <- vector()
  
  selInd<-promat_yixiao[row.names(promat_yixiao) == protSel,]
  if (nrow(selInd) == 1) {
    df_ratio_yixiao[i,] <- selInd
    print(i)
  } 
  
}
row.names(df_ratio_yixiao) <- feature$x
names(df_ratio_yixiao) <- names(promat_yixiao)
df_ratio_yixiaoSel<-df_ratio_yixiao[apply(is.na(df_ratio_yixiao)==T,1,sum)!=ncol(df_ratio_yixiao),]
names_df_ratio_yixiao <- row.names(df_ratio_yixiaoSel)
t_df_ratio_yixiao <- data.frame(t(df_ratio_yixiaoSel))
names(t_df_ratio_yixiao) <- names_df_ratio_yixiao

fin_matirx_yixiao <- data.frame(matrix(0,nrow = nrow(classDefinitions_yixiao), ncol = ncol(t_df_ratio_yixiao)))
for(i in 1:nrow(classDefinitions_yixiao)){
  protSel <- classDefinitions_yixiao$MSID[i]
  selInd <- vector()
  
  selInd<-t_df_ratio_yixiao[row.names(t_df_ratio_yixiao) == protSel,]
  
  fin_matirx_yixiao[i,] <- selInd
  # print(i)
}
row.names(fin_matirx_yixiao) <- classDefinitions_yixiao$MSID
fin_matirx_yx <- data.frame(classDefinitions_yixiao, fin_matirx_yixiao)
row.names(fin_matirx_yx) <- fin_matirx_yx$MSID
names(fin_matirx_yx) <- c(names(classDefinitions_yixiao),names(t_df_ratio_yixiao))
# fin_matirx_yx[4:21]<-data.frame(apply(fin_matirx_yx[4:21],2,scale))
# delect the features that yixiao's data don't have
fin_matirx_2_1 <- data.frame(matrix(NA,nrow=nrow(fin_matirx),ncol=(ncol(fin_matirx_yx)-3)))
for(i in 1:(ncol(fin_matirx_yx)-3)){
  silend<-names(fin_matirx_yx)[i+3]
  fin_matirx_2_1[,i]<-fin_matirx[,names(fin_matirx)==silend]
  print(i)
}
fin_matirx_2<-cbind(fin_matirx[,1:3], fin_matirx_2_1)
names(fin_matirx_2)<-c(names(infoNoQC),names(fin_matirx_yx)[4:15])

yixiao_feature<-names(fin_matirx_yx)[4:15]
fin_feature<-names(fin_matirx)[4:28]
fin_matirx_dy<-fin_matirx_d
for(i in 1:length(yixiao_feature)){
  feayx<-yixiao_feature[i]
  fin_matirx_dy<-fin_matirx_dy[,names(fin_matirx_dy)!=feayx]
}

fin_matirx_yx2<-data.frame(matrix(NA,nrow = nrow(fin_matirx_yx),ncol = (ncol(fin_matirx_dy)-3)))
for(i in 1:(ncol(fin_matirx_dy)-3)){
  dmf_y<-names(fin_matirx_dy)[i+3]
  meanf_y<-mean((fin_matirx_dy)[,(i+3)])
  fin_matirx_yx2[,i]<-meanf_y
}
names(fin_matirx_yx2)<-names(fin_matirx_dy)[4:16]
row.names(fin_matirx_yx2)<-row.names(fin_matirx_yx)
fin_matirx_yx_all<-cbind(fin_matirx_yx,fin_matirx_yx2)
# fin_matirx_yx_all <- fin_matirx_yx_all[c(1:6,16:21),]
# final_matirx_yixiao_all_scale_1<-data.frame(apply(fin_matirx_yx_all[4:28],1,scale))
# fin_matirx_yx_all<-data.frame(fin_matirx_yx_all[,1:3],t(final_matirx_yixiao_all_scale_1))

fin_matirx_yx_all[,4:15]<-data.frame(apply(fin_matirx_yx_all[,4:15],2,scale))
row.names(fin_matirx_yx_all)<-row.names(classDefinitions_yixiao)

# nanames(fin_matirx_yx2)mes(fin_matirx_yx_all)<-c(names(classDefinitions_yixiao),names(t_df_ratio_yixiao),names(fin_matirx_yx2))
# fin_matirx_2$typeLabel<-as.factor(fin_matirx_2$typeLabel)
# # fin_matirx_2[4:21]<-data.frame(apply(fin_matirx_2[4:21],2,scale))
# # train the model again
# set.seed(2)
# TTR_Y<-0
# allcc_m_2 <- 0
# TrainInd_y <- 0
# rfAll_2<-list()
# for(i in 1:100){
#   Folds<-createFolds(fin_matirx_2$typeLabel,10)
#   fin_matirx_2$typeLabel <- as.factor(fin_matirx_2$typeLabel)
#   for(m in 1:length(Folds)){
#     TrainInd<-(1:nrow(fin_matirx_2))[-unlist(Folds[m])]
#     ValInd<-(1:nrow(fin_matirx_2))[unlist(Folds[m])]
# #    set.seed(0)
#     rf2<-randomForest(x=as.matrix(fin_matirx_2[TrainInd,4:ncol(fin_matirx_2)]), y=fin_matirx_2$typeLabel[TrainInd],ntree=5000,nodesize=1)
#     confMat<-(rf2$confusion)
#     TrACC<-(confMat[1,1]+confMat[2,2])/sum(confMat[1,1]+confMat[2,2]+confMat[2,1]+confMat[1,2])
#     predictVal <- predict(rf2, fin_matirx_2[ValInd,4:ncol(fin_matirx_2)],type = "prob")[,1]
#     predictLabel<-as.numeric(predictVal<0.5)+1
#     ValACC<-sum(predictLabel==as.numeric(fin_matirx_2$typeLabel[ValInd]))/length(predictLabel)#0,1; 1,2
#     fin_matirx_yx$typeLabel<-as.factor(fin_matirx_yx$typeLabel)
#     predictVal <- predict(rf2, fin_matirx_yx[,4:ncol(fin_matirx_yx)],type = "prob")[,1]
#     predictLabel<-as.numeric(predictVal<0.5)+1
#     TesACC_yixiao<-sum(predictLabel==as.numeric(fin_matirx_yx$typeLabel))/length(predictLabel)
#     allcc<-TrACC+TesACC_yixiao
#     Top_f<-rf2$importance[2]
#     if(ValACC>=0.8&TrACC>=0.8){
#       TTR_Y<-Top_f
#       allcc_m_2<-allcc
#       TrACC_m_2<-TrACC
#       ValACC_m_2<-ValACC
#       TesACC_yixiao_m<-TesACC_yixiao
#       TrainInd_y<-TrainInd
#       rfAll_2<-rf2
#       print(paste(TrACC_m_2,ValACC_m_2,TesACC_yixiao_m,allcc_m_2,Top_f))
#     }
#     # allcc<-TrACC+ValACC
#     # if(allcc>allcc_m_2){
#     #   allcc_m_2<-allcc
#     #   TrACC_m_2<-TrACC
#     #   ValACC_m_2<-ValACC
#     #   rfAll_2<-rf2
#     #   print(paste(TrACC_m_2,ValACC_m_2,allcc_m_2))
#     # }
#   }
#   print(i)
# }
# 
# rf2_1<-randomForest(x=as.matrix(fin_matirx_2[TrainInd_y,4:ncol(fin_matirx_2)]), y=fin_matirx_2$typeLabel[TrainInd_y],ntree=5000,nodesize=1)


# test the model
fin_matirx_yx_all$typeLabel<-as.factor(fin_matirx_yx_all$typeLabel)
predictVal <- predict(rfAll, fin_matirx_yx_all[,4:ncol(fin_matirx_yx_all)],type = "prob")[,1]
predictLabel<-as.numeric(predictVal<0.5)+1
TesACC_yixiao<-sum(predictLabel==as.numeric(fin_matirx_yx_all$typeLabel))/length(predictLabel)

test.response_yx_all<-as.numeric(fin_matirx_yx_all$typeLabel)
test.predictor_yx_all<-as.numeric(predictVal)
r_test_yx<-roc(test.response_yx_all,test.predictor_yx_all)
pdf("yixiao_test_auc_20200714_all_protein.pdf",width=4,height=4)
plot.roc((r_test_yx),print.auc=T,legacy.axes = TRUE)
dev.off()
# predict result
mean_yx<-apply(fin_matirx_yx_all[4:16],1,mean)



# umap
set.seed(2)
fin_matirx_yx_all_umap<-fin_matirx_yx_all[,c(-1,-3)]
fin_matirx_yx_all_umap$mean<-mean_yx
names(fin_matirx_yx_all_umap)<-c("label",names(fin_matirx_yx_all)[4:28],"mean")
tmp <- fin_matirx_yx_all_umap[,colnames(fin_matirx_yx_all_umap)!='label']
a <- umap(tmp)
fin_matirx_yx_all_umap_df1 <- data.frame(a$layout)
fin_matirx_yx_all_umap_df1$label <- fin_matirx_yx_all_umap$label
fin_matirx_yx_all_umap_df1$ID <- row.names(fin_matirx_yx_all)
colnames(fin_matirx_yx_all_umap_df1) <- c('X','Y','label','ID')
p <- ggplot(fin_matirx_yx_all_umap_df1, aes(x=X, y=Y, colour=label)) + geom_point(size=4)+
  theme(  panel.grid.major = element_blank(),
                 panel.grid.minor = element_blank(),
                 panel.border = element_blank(),
                 plot.title   = element_text(size=16),
                 axis.line.x = element_line(color="black", size = 0.5),
                 axis.line.y = element_line(color="black", size = 0.5),
                 
                 panel.background = element_blank())+
geom_text(
  label = fin_matirx_yx_all_umap_df1$ID,
  colour = "blue",
  size = 2,
  nudge_y = 0.1
)+
  scale_color_manual(limits=c("Non-Severe","Severe"), values=c("#E29827","#922927"))+
  labs(title = "Umap_TMT_data")
pdf("yixiao_test_umap_20200710.pdf",width=8,height=8)
p
dev.off()
#strLabx <- sprintf("PC1(%4.2f%%)",percentages[1]*100)

# fin_matirx_yx_all_umap_m1 <- prcomp(tmp,colNormalization)
set.seed(2)
color<-c("#5F81B5","#E39925")
source("common_change_label.R")
p<-drawPCA(fin_matirx_yx_all_umap,color,F,T,"TMT_PCA")
pdf("yixiao_test_PCA_20200715_all_protein.pdf",width=8,height=8)
p
dev.off()

fin_matirx_yx_predict<-data.frame(predictVal,mean_yx,fin_matirx_yx_all$typeLabel,row.names(fin_matirx_yx_all))
names(fin_matirx_yx_predict)<-c("sample","value","group","type")

a <- ggplot(fin_matirx_yx_predict,aes(x=sample,y=value,group=group,color=group))+ 
  geom_point()+geom_vline(xintercept = 0.5 ,linetype="dotted")+
  ggtitle(paste0("yixiao_pointplot"))+
  xlab("sample")+
  ylab("value")+
  theme(legend.text = element_text(size = 15,color = "black"),legend.position = 'top',
        legend.title = element_text(size=15,color="black") ,
        panel.grid.major =element_blank(),
        panel.grid.minor = element_blank(),
        panel.background = element_blank(),
        axis.line = element_line(colour = "black"))+
  theme(panel.grid =element_blank())+
  theme(axis.text = element_text(size = 10,color = "black"))+
  theme(axis.text.x = element_text( hjust = 1,angle = 45))+
  theme(plot.subtitle=element_text(size=30, hjust=0, color="black"))+
  theme(axis.title.x=element_text(size=17, hjust=0.5, color="black"))+
  theme(axis.title.y=element_text(size=17, hjust=0.5, color="black"))+  geom_text(aes(label=type,vjust = -0.8, hjust = 0.5),show.legend = FALSE)+
  scale_color_manual(limits=c("Non-Severe","Severe"), values=c("#E29827","#922927"))

pdf("yixiao_test_predict_20200710.pdf",width=8,height=8)
print(a)
dev.off()




# load markus's data
promat_markus <- read.csv("all_markus_exp.csv", stringsAsFactors = F, row.names = 1)
row_name_markus <- row.names(promat_markus)
# promat_markus[138:357,]<-log2(promat_markus[138:357,])
# promat_markus<- data.frame(sapply(promat_markus,scale))
# promat_markus<-data.frame(apply(promat_markus,2,scale))
# promat_markus<-normalizeBetweenArrays(promat_yixiao,method = markus)
# promart_markus_2<-preProcess(promat_markus,method = c("range"))
# promat_markus<-predict(promart_markus_2,promat_markus)
row.names(promat_markus) <- row_name_markus 
promat_names<-gsub("X","",colnames(promat_markus))
names(promat_markus)<-promat_names
promat_markus<-promat_markus[apply(is.na(promat_markus),1,sum)!=ncol(promat_markus),]
classDefinitions_markus <- read.csv("20200506_sampleinfo_exp.cohort_JH_20200608_critical_to_severe.csv", stringsAsFactors = F, row.names = 1)
classDefinitions_markus <- classDefinitions_markus[,c(2,5:6)]
feature <- read.csv("feaSel_protein_20200606_MIX.csv", stringsAsFactors = F,row.names = 1)
# identical(colnames(promat_markus), classDefinitions_markus$MSID)

df_ratio_markus <- data.frame(matrix(NA,nrow = nrow(feature), ncol = ncol(promat_markus)))
for(i in 1:nrow(feature)){
  protSel <- feature$x[i]
  selInd <- vector()
  
  selInd<-promat_markus[row.names(promat_markus) == protSel,]
  if (nrow(selInd) == 1) {
    df_ratio_markus[i,] <- selInd
    print(i)
  } 
  
}
row.names(df_ratio_markus) <- feature$x
names(df_ratio_markus) <- names(promat_markus)
df_ratio_markusSel<-df_ratio_markus[apply(is.na(df_ratio_markus)==T,1,sum)!=ncol(df_ratio_markus),]
names_df_ratio_markus <- row.names(df_ratio_markusSel)
t_df_ratio_markus <- data.frame(t(df_ratio_markusSel))
names(t_df_ratio_markus) <- names_df_ratio_markus



# fin_matirx_markus <- data.frame(matrix(0,nrow = nrow(classDefinitions_markus), ncol = ncol(t_df_ratio_markus)))
# for(i in 1:nrow(classDefinitions_markus)){
#   protSel <- unlist(strsplit(row.names(classDefinitions_markus)[i],"_"))[1]
#   selInd <- vector()
#   selInd <- c(selInd,which(grepl(protSel,row.names(t_df_ratio_markus))))
# 
#   
#   fin_matirx_markus[i,] <- t_df_ratio_markus[selInd,]
#   # print(i)
# }
# row.names(fin_matirx_markus) <- classDefinitions_markus$severity
# fin_matirx_yx <- data.frame(classDefinitions_markus, fin_matirx_markus)
# row.names(fin_matirx_yx) <- fin_matirx_yx
# names(fin_matirx_yx) <- c(names(classDefinitions_markus),names(t_df_ratio_markus))
# fin_matirx <- fin_matirx_yx

classDefinitions_markusSort<-classDefinitions_markus[order(row.names(classDefinitions_markus)),]

fin_matirx_1<-cbind(classDefinitions_markusSort,t_df_ratio_markus)
indSel<-which(fin_matirx_1$severity=="mild"|fin_matirx_1$severity=="severe")
fin_matirx_markus<-fin_matirx_1[indSel,]
# fin_matirx_markus[3:19]<-data.frame(apply(fin_matirx_markus[3:19],2,scale))
# delect the features that yixiao's data don't have
fin_matirx_3_1 <- data.frame(matrix(NA,nrow=nrow(fin_matirx),ncol=(ncol(fin_matirx_markus)-2)))
for(i in 1:(ncol(fin_matirx_markus)-2)){
  silend<-names(fin_matirx_markus)[i+2]
  fin_matirx_3_1[,i]<-fin_matirx[,names(fin_matirx)==silend]
  print(i)
}
fin_matirx_3<-cbind(fin_matirx[,1:3], fin_matirx_3_1)
names(fin_matirx_3)<-c(names(infoNoQC),names(fin_matirx_markus)[4:14])

# add missing features of markus
markus_feature<-names(fin_matirx_markus)[4:14]
fin_feature<-names(fin_matirx)[4:28]
fin_matirx_dm<-fin_matirx_d
for(i in 1:length(markus_feature)){
  feamar<-markus_feature[i]
  fin_matirx_dm<-fin_matirx_dm[,names(fin_matirx_dm)!=feamar]
}

fin_matirx_makrus2<-data.frame(matrix(NA,nrow = nrow(fin_matirx_markus),ncol = (ncol(fin_matirx_dm)-3)))
for(i in 1:(ncol(fin_matirx_dm)-3)){
  dmf<-names(fin_matirx_dm)[i+3]
  meanf<-mean((fin_matirx_dm)[,(i+3)])
  fin_matirx_makrus2[,i]<-meanf
}
names(fin_matirx_makrus2)<-names(fin_matirx_dm)[4:17]
row.names(fin_matirx_makrus2)<-row.names(fin_matirx_markus)
fin_matirx_markus_all<-cbind(fin_matirx_markus,fin_matirx_makrus2)
fin_matirx_markus_all[,4:20]<-data.frame(apply(fin_matirx_markus_all[,4:14],2,scale))

# fin_matirx_markus_all<-fin_matirx_markus_all[fin_matirx_markus_all$timepoint!="A"&fin_matirx_markus_all$timepoin!="B",]
# fin_matirx_3[4:20]<-data.frame(apply(fin_matirx_3[4:20],2,scale))
##########
# fin_matirx_3$typeLabel<-as.factor(fin_matirx_3$typeLabel)
# fin_matirx_markus$severity<-as.factor(fin_matirx_markus$severity)
# rf4<-randomForest(x=as.matrix(fin_matirx_markus[,3:ncol(fin_matirx_markus)]), y=fin_matirx_markus$severity,ntree=5000,nodesize=5)
# predictVal<-predict(rf4,fin_matirx_3[,4:ncol(fin_matirx_3)],type = "prob")[,1]
# predictLabel<-as.numeric(predictVal<0.5)+1
# TesACC_1<-sum(predictLabel==as.numeric(fin_matirx_3$typeLabel))/length(predictLabel)

#########

# build the model again
# TTR_MAX<-0
# fin_matirx_3$typeLabel<-as.factor(fin_matirx_3$typeLabel)
# allcc_m_3 <- 0
# TesACC_makrus_m<-0
# TrainInd_m <- 0
# rfAll_3<-list()
# set.seed(0)
# for(i in 1:100){
#   Folds<-createFolds(fin_matirx_3$typeLabel,10)
#   fin_matirx$typeLabel <- as.factor(fin_matirx_3$typeLabel)
#   for(m in 1:length(Folds)){
#     TrainInd<-(1:nrow(fin_matirx_3))[-unlist(Folds[m])]
#     ValInd<-(1:nrow(fin_matirx_3))[unlist(Folds[m])]
#     rf3<-randomForest(x=as.matrix(fin_matirx_3[TrainInd,4:ncol(fin_matirx_3)]), y=fin_matirx_3$typeLabel[TrainInd],ntree=5000,nodesize=1)
#     confMat<-(rf3$confusion)
#     TrACC<-(confMat[1,1]+confMat[2,2])/sum(confMat[1,1]+confMat[2,2]+confMat[2,1]+confMat[1,2])
#     predictVal <- predict(rf3, fin_matirx_3[ValInd,4:ncol(fin_matirx_3)],type = "prob")[,1]
#     predictLabel<-as.numeric(predictVal<0.5)+1
#     ValACC<-sum(predictLabel==as.numeric(fin_matirx_3$typeLabel[ValInd]))/length(predictLabel)#0,1; 1,2
#     fin_matirx_markus$severity<-as.factor(fin_matirx_markus$severity)
#     predictVal <- predict(rf3, fin_matirx_markus[,3:ncol(fin_matirx_markus)],type = "prob")[,1]
#     predictLabel<-as.numeric(predictVal<0.5)+1
#     TesACC_markus<-sum(predictLabel==as.numeric(fin_matirx_markus$severity))/length(predictLabel)
#     allcc<-TrACC+TesACC_markus
#     Top_f<-rf3$importance[1]+rf3$importance[2]+rf3$importance[3]
#     if(ValACC>=0.8&TrACC>=0.8){
#       TTR_MAX<-Top_f
#       allcc_m_3<-allcc
#       TrACC_m_3<-TrACC
#       ValACC_m_3<-ValACC
#       TesACC_markus_m<-TesACC_markus
#       rfAll_3<-rf3
#       TrainInd_m<-TrainInd
#       print(paste(TrACC_m_3,ValACC_m_3,TesACC_markus_m,allcc_m_3,Top_f))
#     }
#     # allcc<-TrACC+ValACC
#     # if(allcc>allcc_m_3){
#     #   allcc_m_3<-allcc
#     #   TrACC_m_3<-TrACC
#     #   ValACC_m_3<-ValACC
#     #   rfAll_3<-rf3
#     #   print(paste(TrACC_m_3,ValACC_m_3,allcc_m_3))
#     # }
#   }
#   print(i)
# }
# 
# rf3_1<-randomForest(x=as.matrix(fin_matirx_3[TrainInd_m,4:ncol(fin_matirx_3)]), y=fin_matirx_3$typeLabel[TrainInd_m],ntree=5000,nodesize=1)
# 

fin_matirx_markus_all$severity<-as.factor(fin_matirx_markus_all$severity)
predictVal_markus <- predict(rfAll, fin_matirx_markus_all[,4:ncol(fin_matirx_markus_all)],type = "prob")[,1]
predictLabel_markus<-as.numeric(predictVal_markus<0.5)+1
TesACC_makrus<-sum(predictLabel_markus==as.numeric(fin_matirx_markus_all$severity))/length(predictLabel_markus)

test.response<-as.numeric(fin_matirx_markus_all$severity)
test.predictor<-as.numeric(predictVal_markus)
r_test<-roc(test.response,test.predictor)
pdf("markus_test_auc_20200714_all_protein.pdf",width=4,height=4)
plot.roc((r_test),print.auc=T,legacy.axes = TRUE)
dev.off()
# predict result
type_m<-vector()
for(i in 1:nrow(fin_matirx_markus_all)){
  type_m_1<-unlist(strsplit(fin_matirx_markus_all$ID[i],"-"))[4]
  type_m_2<-unlist(strsplit(fin_matirx_markus_all$ID[i],"-"))[5]
  type_m[i]<-paste0(type_m_1,type_m_2)
}
mean_markus<-apply(fin_matirx_markus_all[4:14],1,mean)



# umap
set.seed(2)
fin_matirx_markus_all_umap<-fin_matirx_markus_all[,c(-1,-2)]
fin_matirx_markus_all_umap$mean<-mean_markus
names(fin_matirx_markus_all_umap)<-c("label",names(fin_matirx_markus_all)[4:28],"mean")
tmp_m <- fin_matirx_markus_all_umap[,colnames(fin_matirx_markus_all_umap)!='label']
a_m <- umap(tmp_m)
fin_matirx_markus_all_umap_df1 <- data.frame(a_m$layout)
fin_matirx_markus_all_umap_df1$label <- fin_matirx_markus_all_umap$label
fin_matirx_markus_all_umap_df1$ID <- type_m
colnames(fin_matirx_markus_all_umap_df1) <- c('X','Y','label','ID')
p <- ggplot(fin_matirx_markus_all_umap_df1, aes(x=X, y=Y, colour=label)) + geom_point(size=4)+
  theme(  panel.grid.major = element_blank(),
          panel.grid.minor = element_blank(),
          panel.border = element_blank(),
          plot.title   = element_text(size=16),
          axis.line.x = element_line(color="black", size = 0.5),
          axis.line.y = element_line(color="black", size = 0.5),
          
          panel.background = element_blank())+
  geom_text(
    label = fin_matirx_markus_all_umap_df1$ID,
    colour = "blue",
    size = 2,
    nudge_y = 0.1
  )+
  scale_color_manual(limits=c("mild","severe"), values=c("#E29827","#922927"))+
  labs(title = "Umap_markus_data")
pdf("markus_test_umap_20200710.pdf",width=8,height=8)
p
dev.off()

set.seed(2)
color<-c("#5F81B5","#E39925")
source("common_change_label.R")
p<-drawPCA(fin_matirx_markus_all_umap,color,F,T,"markus_PCA")
pdf("markus_test_PCA_20200715_all_protein.pdf",width=8,height=8)
p
dev.off()

fin_matirx_markus_predict<-data.frame(predictVal_markus,mean_markus,fin_matirx_markus_all$severity,type_m)
names(fin_matirx_markus_predict)<-c("sample","value","group","type")

a <- ggplot(fin_matirx_markus_predict,aes(x=sample,y=value,group=group,color=group))+ 
  geom_point()+geom_vline(xintercept = 0.5 ,linetype="dotted")+
  ggtitle(paste0("markus_pointplot"))+
  xlab("sample")+
  ylab("value")+
  theme(legend.text = element_text(size = 15,color = "black"),legend.position = 'top',
        legend.title = element_text(size=15,color="black") ,
        panel.grid.major =element_blank(),
        panel.grid.minor = element_blank(),
        panel.background = element_blank(),
        axis.line = element_line(colour = "black"))+
  theme(panel.grid =element_blank())+
  theme(axis.text = element_text(size = 10,color = "black"))+
  theme(axis.text.x = element_text( hjust = 1,angle = 45))+
  theme(plot.subtitle=element_text(size=30, hjust=0, color="black"))+
  theme(axis.title.x=element_text(size=17, hjust=0.5, color="black"))+
  theme(axis.title.y=element_text(size=17, hjust=0.5, color="black"))+  geom_text(aes(label=type,vjust = -0.8, hjust = 0.5),show.legend = FALSE)+
  scale_color_manual(limits=c("mild","severe"), values=c("#E29827","#922927"))
 
pdf("markus_test_predict_20200710.pdf",width=8,height=8)
print(a)
dev.off()