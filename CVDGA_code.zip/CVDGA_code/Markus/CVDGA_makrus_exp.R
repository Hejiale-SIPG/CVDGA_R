

BiocManager::install("pROC")

library(randomForest)
library(pROC)
library(ggplot2)
library(dplyr)
rm(list = ls())

pro<-read.csv("original_row_name.csv", stringsAsFactors = F)
for(m in 1:nrow(pro)){
  sss<-unlist(strsplit(pro$ID[m],"/"))
  UniProtNames<-sss[2:length(sss)]
  UniProtIDs<-vector()
  
  for(i in 1:length(UniProtNames)){
    UniProtIDs[i]<-unlist(strsplit(UniProtNames[i],"\\|"))[2]
  }
  UniProtIDs_1[m] <- paste(UniProtIDs,collapse = ";")
  print(m)
}
write.table(UniProtIDs_1, "UniProtIDs_1.txt")


zhangfangfei <- read.csv("1PatientMSID_noName_FZ20200329v3.csv")
caixue <- read.csv("2cxtsne2.csv")
zhangfangfei1 <- zhangfangfei[ , -1: -16]
zhangfangfei2 <- zhangfangfei1[ , -2: -11]
caixue1 <- caixue[ , -1: -2]
caixue2 <- caixue1[ , -2: -23]

overlapped <- base::intersect(caixue2, zhangfangfei2)
write.csv(overlapped, "overlapped.csv")


#FZ
setwd("D:/Qsync/Hejiale/share_data_zff/CVDGA")
readin<-read.csv("All_513_protein_interactome_complex.csv",stringsAsFactors = F)
# protMat<-read.csv("./zff/CVDSSB_proteins_2020426_origin_data_caixue.csv",row.names = 1)
protMat<-read.csv("20200506_quant_exp.cohort_JH_20200606.csv",stringsAsFactors = F, row.names = 1)
promart <- promart[apply(is.na(promart),1,sum)/ncol(promart)<0.8,]
protMat[is.na(protMat)]<-min(protMat,na.rm=T)*0.8

# selInd_2 <- vector()
# selInd_2 <- c(selInd_2,which(grepl("^1/sp",row.names(protMat))))
# protMat_de <- protMat[selInd_2,]
protMat_de <- protMat
readin_1<-read.csv("bioplex_differential_protein_pathway.csv",stringsAsFactors = F)
# protMat_z <- data.frame(matrix(0,nrow=nrow(protMat), ncol=ncol(protMat)), stringsAsFactors = F)
protMat_de_z <- data.frame(sapply(protMat_de,scale))
row.names(protMat_de_z) <- row.names(protMat_de)
protMat_de_2 <- 2^protMat_de
row.names(protMat_de_z) <- c(as.matrix(row.names(protMat_de)))

df_GO <- data.frame(matrix(NA,nrow=nrow(readin), ncol=ncol(protMat_de_z)), stringsAsFactors = F)
row.names(df_GO) <- c(as.matrix((readin[, 1])))
names(df_GO)<-c(as.matrix(names(protMat_de)))
df_GO_p <- data.frame(matrix(NA,nrow=nrow(readin_1), ncol=ncol(protMat_de_z)), stringsAsFactors = F)
row.names(df_GO_p) <- c(as.matrix((readin_1[, 3])))
names(df_GO_p)<-c(as.matrix(names(protMat_de)))

uniAll<-read.csv("uniport_ID_match_gene_ID.csv",stringsAsFactors = F)

readout<-readin
readout_1<-readin_1

for(i in 1:nrow(readin)){
  genNames<-unlist(strsplit(readin$Protein[i],","))
  uniNames<-vector()
  for(m in 1:length(genNames)){
    s_gene <- uniAll$Gene[which(uniAll$Gene==genNames[m])]
    uniNames[m] <- paste(unique(uniAll$Uniport_ID[which(uniAll$Gene==unique(s_gene))]),collapse = ";")
  }
  readout[i,2]<-paste(uniNames,collapse = ",")
}



for(i in 1:nrow(readin_1)){
  genNames<-unlist(strsplit(readin_1$intersections[i],","))
  uniNames<-vector()
  for(m in 1:length(genNames)){
    s_gene <- uniAll$Gene[which(uniAll$Gene==genNames[m])]
    uniNames[m] <- paste(unique(uniAll$Uniport_ID[which(uniAll$Gene==unique(s_gene))]),collapse = ";")
  }
  readout_1[i,11]<-paste(uniNames,collapse = ",")
}


#complex 1 z score
for(m in 1:nrow(readout)){
  protSel<-unlist(strsplit(readin$Protein[m],","))# text to column by ","
  

  
  selInd<-vector()
  for(i in 1:length(protSel)){
    # protMat_deSel<-protMat_de[ which(grepl(protSel[i],row.names(protMat_de))),]
    selInd<-c(selInd,which(grepl(protSel[i],row.names(protMat_de_z))))
  }
  protMat_deSel_z<-protMat_de_z[selInd,]
  protMat_deSel_z <- distinct(protMat_deSel_z)
  df_GO[m,]<-apply(protMat_deSel_z,2,sum,na.rm=T) #sum by row
  

  print(m)
}
row.names(df_GO) <- readin$Protein

# complex 1 expression
for(m in 1:nrow(readout)){
  protSel<-unlist(strsplit(readout$Protein[m],","))# text to column by ","
  
  
  
  selInd<-vector()
  for(i in 1:length(protSel)){
    # protMat_deSel<-protMat_de[ which(grepl(protSel[i],row.names(protMat_de))),]
    selInd<-c(selInd,which(grepl(protSel[i],row.names(protMat_de_2))))
  }
  protMat_deSel_2<-protMat_de_2[selInd,]
  protMat_deSel_2 <- distinct(protMat_deSel_2)
  df_GO[m,]<-apply(protMat_deSel_2,2,sum,na.rm=T) #sum by row
  
  
  print(m)
}
row.names(df_GO) <- readin$Protein
for(i in 1:ncol(df_GO)){
  df_GO[is.na(df_GO[,i]),i] <- min(df_GO[,i],na.rm=T)
}

df_GO_1 <- log2(df_GO)

#pathway 1
for(m in 1:nrow(readout_1)){
  protSel<-unlist(strsplit(readin_1$intersections[m],","))# text to column by ","
  
  
  
  selInd<-vector()
  for(i in 1:length(protSel)){
    # protMat_deSel<-protMat_de[ which(grepl(protSel[i],row.names(protMat_de))),]
    selInd<-c(selInd,which(grepl(protSel[i],row.names(protMat_de_z))))
  }
  protMat_deSel_z<-protMat_de_z[selInd,]
  protMat_deSel_z <- distinct(protMat_deSel_z)
  df_GO_p[m,]<-apply(protMat_deSel_z,2,sum,na.rm=T) #sum by row
  
  
  print(m)
}

#pathway 1
for(m in 1:nrow(readout_1)){
  protSel<-unlist(strsplit(readout_1$intersections[m],","))# text to column by ","
  
  
  
  selInd<-vector()
  for(i in 1:length(protSel)){
    # protMat_deSel<-protMat_de[ which(grepl(protSel[i],row.names(protMat_de))),]
    selInd<-c(selInd,which(grepl(protSel[i],row.names(protMat_de_2))))
  }
  protMat_deSel_2<-protMat_de_2[selInd,]
  protMat_deSel_2 <- distinct(protMat_deSel_2)
  df_GO_p[m,]<-apply(protMat_deSel_2,2,sum,na.rm=T) #sum by row
  
  
  print(m)
}
for(i in 1:ncol(df_GO_p)){
  df_GO_p[is.na(df_GO_p[,i]),i] <- min(df_GO_p[,i],na.rm=T)
}

  df_GO_p_1 <- log2(df_GO_p)


# sum HJL####
protRatioNames<-vector();m=1
for(i in 1:nrow(readout)){
  prot_sp<-unlist(strsplit(readout$Protein[i],","))
  comb<-combn(1:length(prot_sp),2)
  for(j in 1:ncol(comb))  {
    protRatioNames[m]<-paste(prot_sp[comb[,j]],collapse = "/")
    m<-m+1
  }
}

protRatMat<-data.frame(matrix(0,nrow=length(protRatioNames),ncol=ncol(protMat_de)))
row.names(protRatMat)<-protRatioNames
colnames(protRatMat)<-colnames(protMat_de)

for(i in 1:nrow(protRatMat)){
  selProt<-unlist(strsplit(row.names(protRatMat)[i],"/"))
  selInd<-vector()
  for(m in 1:length(selProt)){
    # protMat_deSel<-protMat_de[ which(grepl(protSel[i],row.names(protMat_de))),]
    selInd<-c(selInd,which(grepl(selProt[m],row.names(protMat_de_2))))
  }
  protMat_deSel_2 <- protMat_de_2[selInd,] 
  protMat_deSel_2_fi <- protMat_deSel_2[1,]/protMat_deSel_2[2,]
  protRatMat[i,]<-protMat_deSel_2_fi #sum by row
}

for(i in 1:nrow(protRatMat)){
  uniportID <- unlist(strsplit(row.names(protRatMat)[i],"/"))
  gene_names <- vector()
  for(m in 1:length(uniportID)){
    s_uniportID <- uniAll$Uniport_ID[which(uniAll$Uniport_ID==uniportID[m])]
    gene_names[m] <- paste(unique(uniAll$Gene[which(uniAll$Uniport_ID == unique(s_uniportID))]),collapse = ";")
  }
  row.names(protRatMat)[i]<-paste(gene_names,collapse = "/")
}
write.csv(df_GO, "complex_matrix_20200606_markus.csv")
write.csv(df_GO_p, "pathway_matrix_2020606_markus.csv")
write.csv(protRatMat, "ratio_matrix_20200520_yixiao.csv")
df_GO_z <- protRatMat


df_GO_z <- df_GO_p

df_GO_z <- df_GO

write.csv(df_GO_z, "df_GO_matrix_z.csv")


# draw a map
#df_GOMat<-read.csv('df_GO_matrix_1.csv',stringsAsFactors = F
#                   ,row.names = 1)




df_GOMat <- df_GO_z

LabelIN<-read.csv("sample_labelFZ.csv",stringsAsFactors = F,row.names = 1)

apply(df_GOMat)

df_GOMatNoQC<-df_GOMat[,!grepl("QC",colnames(df_GOMat))]
dayLabel<-typeLabel<-vector()
for(j in 1:ncol(df_GOMatNoQC)){
  samN<-unlist(strsplit(unlist(strsplit(colnames(df_GOMatNoQC)[j],"\\."))[1],"_"))[5]
  dayLabel[j]<-LabelIN[LabelIN$sample_N==samN,"label"]
  typeLabel[j]<-LabelIN[LabelIN$sample_N==samN,"clinical"]
}

df_GOMatNoQCZ<-apply(df_GOMatNoQC,2,scale)

pdf("PathSumTrend_z_pathway_1.pdf")
for(i in 1:nrow(df_GOMatNoQC)){
  protSel<-df_GOMatNoQC[i,]
  df_protLabel<-data.frame(cbind(t(protSel),dayLabel,typeLabel),stringsAsFactors = F)
  colnames(df_protLabel)[1]<-"prot"
  df_protLabel[,1]<-as.numeric(df_protLabel[,1])
  df_protLabel[,2]<-as.numeric(df_protLabel[,2])
  
  g1<-ggplot(df_protLabel, aes(x=dayLabel,y=prot))+theme_bw() + coord_cartesian(xlim=c(1,5))+
    scale_color_manual(limits=c("Severe","Non-Severe"), values=c("#F4AA62","#72A6C8"))+
    scale_fill_manual(limits=c("Severe","Non-Severe"), values=c("#F4AA62","#72A6C8"))+
    theme(panel.grid =element_blank()) + theme(legend.title = element_blank())+ geom_smooth(aes(fill =(factor(typeLabel)),color =(factor(typeLabel))))+ggtitle(row.names(df_GO)[i])  + labs(y="Sum Abundance", x = "Stage")+geom_point(aes(x=0, y=median(df_protLabel$prot[df_protLabel$typeLabel=="Healthy"])), col="red") +
    geom_point(aes(x=0, y=median(df_protLabel$prot[df_protLabel$typeLabel=="non-COVID"])), col="orange")
      
  print(g1)
}
dev.off()

# match differentical complexs, ratios and pathways
c_d <- read.csv("Differential_complex_1.csv",stringsAsFactors = F) 
r_d <- read.csv("Differential_ratio_1.csv",stringsAsFactors = F) 
p_d <- read.csv("Differential_pathway_1.csv",stringsAsFactors = F) 

# complexs
complexs <- data.frame(matrix(0,nrow=nrow(c_d), ncol=ncol(protMat_de_z)),stringsAsFactors = F)
row.names(complexs) <- c_d[,1]
names(complexs) <- names(protMat_de_2)
selInd_c <- vector()
for(i in 1:nrow(complexs)){
  selInd_c<-c(selInd_c,which(grepl(row.names(complexs)[i],row.names(df_GO))))
}
complex_1 <- df_GO[selInd_c,]

write.csv(complex_1, "differential_complex_matrix_yixiao.csv")

# ratios
ratios <- data.frame(matrix(0,nrow=nrow(r_d), ncol=ncol(protMat_de_z)),stringsAsFactors = F)
row.names(ratios) <- r_d[,1]
names(ratios) <- names(protMat_de_z)
selInd_r <- vector()
for(i in 1:nrow(ratios)){
  selInd_r<-c(selInd_r,which(grepl(row.names(ratios)[i],row.names(protRatMat))))
}
ratio_1 <- protRatMat[selInd_r,]
write.csv(ratio_1, "differential_ratio_matrix_yixiao.csv")

# pathways
pathways <- data.frame(matrix(0,nrow=nrow(p_d), ncol=ncol(protMat_de_2)),stringsAsFactors = F)
row.names(pathways) <- p_d[,1]


names(pathways) <- names(protMat_de_2)
selInd_p <- vector()
for(i in 1:nrow(pathways)){
  selInd_p<-c(selInd_p,which(grepl(row.names(pathways)[i],row.names(df_GO_p))))
}
pathway_1 <- df_GO_p[selInd_p,]
pathway_1 <- pathway_1[-6:-8,]
write.csv(pathway_1, "differential_pathway_matrix_yixiao.csv")



