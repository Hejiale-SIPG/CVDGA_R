library("Biobase")
library("limma")
library("GSA")
library("RCurl")

rm(list = ls())



promart <- read.csv("all_column_20200531_MIX.csv", stringsAsFactors = F, row.names = 1)
sample_lable <- read.csv("sample_labelFZ.csv", stringsAsFactors = F)
sample_lable <- sample_lable[,-1]
names_promat <- row.names(promart)
t_promat <- data.frame(t(promart))
names(t_promat) <- names_promat
t_promatNoQC <- t_promat[!grepl("QC",row.names(t_promat)),]
promartNOQC <- data.frame(t(t_promatNoQC)) 
info <- data.frame(matrix(0,nrow = nrow(t_promatNoQC), ncol = 3))
row.names(info) <- row.names(t_promatNoQC)
names(info) <- c("typeLabel", "dayLabel","patient_id")
infoNoQC <- info

dayLabel <- typeLabel <- patientLabel <- vector()
for(j in 1:nrow(infoNoQC)) {
  samN <- unlist(strsplit(unlist(strsplit(row.names(infoNoQC)[j],"\\."))[1],"_"))[5]
  typeLabel[j] <- sample_lable[sample_lable$sample_N == samN,"clinical"]
  dayLabel[j] <- sample_lable[sample_lable$sample_N==samN,"label"]
  patientLabel[j] <- sample_lable[sample_lable$sample_N==samN,"PatientID_2"]
  infoNoQC[j, ] <- c(typeLabel[j],dayLabel[j],patientLabel[j])
  print(j)
}

newmart <- data.frame(infoNoQC, t_promatNoQC)
names(newmart) <- c(names(infoNoQC),names(t_promatNoQC))
newmart <- newmart[newmart$dayLabel==1,]

expressionMatrix <- as.matrix(t(newmart[,-1:-3]))
classDefinitions <- newmart[,1:3]

identical(colnames(expressionMatrix), row.names(classDefinitions))

minimalSet <- ExpressionSet(assayData=expressionMatrix) # Format data
classes <- factor(classDefinitions[,"typeLabel"]) # Class definitions

modelDesign <- model.matrix(~ 0 + classes) # Create a model matrix with the defined classes
fit <- lmFit(minimalSet, modelDesign) 

contrast.matrix <- makeContrasts(
  Severe_nonSevere = "classesSevere - classesNon_Severe",
  levels=modelDesign) # Create the contrast matrix

fit1 <- contrasts.fit(fit, contrast.matrix) # Model contrsts of gene expression
fit2 <- eBayes(fit1) # compute differential expression statistics
topfitSevere_nonSevere <- topTable(fit2, coef="Severe_nonSevere",number=nrow(expressionMatrix), adjust="BH")


length(which(topfitSevere_nonSevere$P.Val<0.05))


Severe_nonSevere <- topfitSevere_nonSevere[which(topfitSevere_nonSevere$P.Val<0.05),]


write.csv(Severe_nonSevere, "Severe_nonSevere_limma_20200531_CVDSA_level_1_p0.05_gene_name_level_1_mix.csv")
