library(randomForest)
library(pROC)
library(party)
library(caret)
library(dplyr)

limma_Severe_nonSevere <- read.csv("Severe_nonSevere_limma_20200531_CVDSA_level_1_p0.05_gene_name_level_1_mix.csv", stringsAsFactors = F, row.names = 1)
promart <- read.csv("all_column_20200531_MIX.csv", stringsAsFactors = F, row.names = 1)
sample_lable <- read.csv("sample_labelFZ.csv", stringsAsFactors = F)
sample_lable <- sample_lable[,-1]
names_promat <- row.names(promart)
promart_1 <- data.frame(matrix(NA, ncol=ncol(promart), nrow=nrow(limma_Severe_nonSevere)))
for (i in 1:nrow(limma_Severe_nonSevere)) {
  protSel <- row.names(limma_Severe_nonSevere)[i]
  selind <- vector()
  selind <- promart[row.names(promart)==protSel,]
  promart_1[i,] <- selind
}
row.names(promart_1) <- row.names(limma_Severe_nonSevere)
names(promart_1) <- names(promart)
names_promat_1 <- row.names(promart_1)
t_promat <- data.frame(t(promart_1))
names(t_promat) <- names_promat_1
t_promatNoQC <- t_promat[!grepl("QC",row.names(t_promat)),]

info <- data.frame(matrix(0,nrow = nrow(t_promatNoQC), ncol = 3))
row.names(info) <- row.names(t_promatNoQC)
names(info) <- c("typeLabel", "dayLabel","patient_id")
infoNoQC <- info

dayLabel <- typeLabel <- patientLabel <- vector()
for(j in 1:nrow(infoNoQC)) {
  samN <- unlist(strsplit(unlist(strsplit(row.names(infoNoQC)[j],"\\."))[1],"_"))[5]
  typeLabel[j] <- sample_lable[sample_lable$sample_N == samN,"clinical"]
  dayLabel[j] <- sample_lable[sample_lable$sample_N==samN,"label"]
  patientLabel[j] <- sample_lable[sample_lable$sample_N==samN,"PatientID_2"]
  infoNoQC[j, ] <- c(typeLabel[j],dayLabel[j],patientLabel[j])
  print(j)
}

fin_matirx <- data.frame(infoNoQC, t_promatNoQC)
names(fin_matirx) <- c(names(infoNoQC),names(t_promatNoQC))
fin_matirx <- fin_matirx[fin_matirx$dayLabel==1&fin_matirx$typeLabel!="Healthy"&fin_matirx$typeLabel!="non-COVID",]

promat_yixiao <- read.csv("all_matrix_20200520_yixiao.csv", stringsAsFactors = F, row.names = 1)
classDefinitions_yixiao <- read.csv("PatientMSID_noName_FZ20200329v3 _1.csv", stringsAsFactors = F, row.names = 1)
classDefinitions_yixiao <- classDefinitions_yixiao[,c(4,5,20)]
identical(colnames(promat_yixiao), classDefinitions_yixiao$MSID)

df_ratio_yixiao <- data.frame(matrix(0,nrow = nrow(limma_Severe_nonSevere), ncol = ncol(promat_yixiao)))
for(i in 1:nrow(limma_Severe_nonSevere)){
  protSel <- row.names(limma_Severe_nonSevere)[i]
  selInd <- vector()
  
  selInd<-promat_yixiao[row.names(promat_yixiao) == protSel,]
  
  df_ratio_yixiao[i,] <- selInd
  # print(i)
}
row.names(df_ratio_yixiao) <- row.names(limma_Severe_nonSevere)
names(df_ratio_yixiao) <- names(promat_yixiao)
names_df_ratio_yixiao <- row.names(df_ratio_yixiao)
t_df_ratio_yixiao <- data.frame(t(df_ratio_yixiao))
names(t_df_ratio_yixiao) <- names_df_ratio_yixiao

fin_matirx_yixiao <- data.frame(matrix(0,nrow = nrow(classDefinitions_yixiao), ncol = ncol(t_df_ratio_yixiao)))
for(i in 1:nrow(classDefinitions_yixiao)){
  protSel <- classDefinitions_yixiao$MSID[i]
  selInd <- vector()
  
  selInd<-t_df_ratio_yixiao[row.names(t_df_ratio_yixiao) == protSel,]
  
  fin_matirx_yixiao[i,] <- selInd
  # print(i)
}
row.names(fin_matirx_yixiao) <- classDefinitions_yixiao$MSID
fin_matirx_yx <- data.frame(classDefinitions_yixiao, fin_matirx_yixiao)
row.names(fin_matirx_yx) <- fin_matirx_yx$MSID
names(fin_matirx_yx) <- c(names(classDefinitions_yixiao),names(t_df_ratio_yixiao))

# for (i in 1:nrow(fin_matirx_yx)) {
#   p_sum <- fin_matirx_yx$pati[i]
#   fin_matirx <- fin_matirx[!fin_matirx$pati == p_sum, ]
# 
# }

#





aucMax <- 0
imp_all <- 0
for(i in 1:100){
  fin_matirx$typeLabel <- as.factor(fin_matirx$typeLabel)
#  fin_matirx_yx$typeLabel <- as.factor(fin_matirx_yx$typeLabel)
  Folds<-createFolds(fin_matirx$typeLabel,10)
#  Folds_v<-createFolds(fin_matirx_v$typeLabel,10)
  ValACC<-TrACC<-TestACC<-vector()
  all.test <- all.response <- all.predictor <- aucs <- vector()
  imp <- 0
  rfAll<-list()
  for(m in 1:length(Folds)){
    TrainInd<-(1:nrow(fin_matirx))[-unlist(Folds[m])]
    ValInd<-(1:nrow(fin_matirx))[unlist(Folds[m])]
#    TesInd<-(1:nrow(fin_matirx_yx))
    rf1<-randomForest(x=as.matrix(fin_matirx[TrainInd,4:ncol(fin_matirx)]), y=fin_matirx$typeLabel[TrainInd],ntree=5000,nodesize=5)
    rfAll[[m]]<-rf1
    confMat<-(rf1$confusion)
    TrACC[m]<-(confMat[1,1]+confMat[2,2])/sum(confMat[1,1]+confMat[2,2]+confMat[2,1]+confMat[1,2])
    
    predictVal <- predict(rf1, fin_matirx[ValInd,4:ncol(fin_matirx)],type = "prob")[,1]
    predictLabel<-as.numeric(predictVal<0.5)+1
    ValACC[m]<-sum(predictLabel==as.numeric(fin_matirx$typeLabel[ValInd]))/length(predictLabel)#0,1; 1,2
    
    
    all.response <- c(all.response, as.numeric(fin_matirx$typeLabel[ValInd]))
    all.predictor <- c(all.predictor, as.numeric(predictVal))
    imp <- imp + rf1$importance
    print(m)
    
  }
  print(paste(mean(TrACC),mean(ValACC)))
  # (mean(aucs))
  r2<-roc(all.response,all.predictor)
  imp_all <- imp_all + imp
  
  
  
  aucRun <- r2$auc
  if (aucRun > aucMax) {
    aucMax <- aucRun
    plot.roc((r2),print.auc=T,legacy.axes = TRUE)
    
    c <- rfAll[[which.max(TrACC+ValACC)]]
    
    varImpPlot(c)
    print(aucRun)
  }
  print(i)
  
}

impRf<- imp_all
feaSel<-names(sort(impRf[,1],decreasing = T))
feaSel<-feaSel[1:25]
write.csv(feaSel,"feaSel_right_20200531_MIX.csv")

finSel_matirx <- fin_matirx[,feaSel[feaSel%in%colnames(fin_matirx)]]

########################################################################
aucMax <- 0
# imp_all <- 0
for(i in 1:100){
  fin_matirx$typeLabel <- as.factor(fin_matirx$typeLabel)
  #  fin_matirx_yx$typeLabel <- as.factor(fin_matirx_yx$typeLabel)
  Folds<-createFolds(fin_matirx$typeLabel,10)
  #  Folds_v<-createFolds(fin_matirx_v$typeLabel,10)
  ValACC<-TrACC<-TestACC<-vector()
  all.test <- all.response <- all.predictor <- aucs <- vector()
#  imp <- 0
  rfAll<-list()
  for(m in 1:length(Folds)){
    TrainInd<-(1:nrow(fin_matirx))[-unlist(Folds[m])]
    ValInd<-(1:nrow(fin_matirx))[unlist(Folds[m])]
    #    TesInd<-(1:nrow(fin_matirx_yx))
    rf1<-randomForest(x=as.matrix(finSel_matirx[TrainInd,1:ncol(finSel_matirx)]), y=fin_matirx$typeLabel[TrainInd],ntree=5000,nodesize=5)
    rfAll[[m]]<-rf1
    confMat<-(rf1$confusion)
    TrACC[m]<-(confMat[1,1]+confMat[2,2])/sum(confMat[1,1]+confMat[2,2]+confMat[2,1]+confMat[1,2])
    
    predictVal <- predict(rf1, finSel_matirx[ValInd,1:ncol(finSel_matirx)],type = "prob")[,1]
    predictLabel<-as.numeric(predictVal<0.5)+1
    ValACC[m]<-sum(predictLabel==as.numeric(fin_matirx$typeLabel[ValInd]))/length(predictLabel)#0,1; 1,2
    
    
    all.response <- c(all.response, as.numeric(fin_matirx$typeLabel[ValInd]))
    all.predictor <- c(all.predictor, as.numeric(predictVal))
#    imp <- imp + rf1$importance
    print(m)
    
    
  }
  print(paste(mean(TrACC),mean(ValACC)))
  # (mean(aucs))
  r2<-roc(all.response,all.predictor)
#  imp_all <- imp_all + imp
  
  
  
  aucRun <- r2$auc
  if (aucRun > aucMax) {
    aucMax <- aucRun
    plot.roc((r2),print.auc=T,legacy.axes = TRUE)
    
    c <- rfAll[[which.max(TrACC+ValACC)]]
    
    varImpPlot(c)
    print(aucRun)
  }
  print(i)
  
}




############################################
library(umap)
source("common_change_label.R")

df<-data.frame(fin_matirx[,1], finSel_matirx)

names(df)<-c("label",names(finSel_matirx))

color<-c("green","red")

set.seed(1)

a<-drawUMAP(df,color,strTitle = "UMAP",F,T)
pdf("umap_caixue_20200531.pdf")
a
dev.off()

################################################
heatmap_info <- data.frame(fin_matirx$typeLabel,finSel_matirx)
names(heatmap_info) <- c("typeLabel",names(finSel_matirx))
heatmap_info_1 <- heatmap_info[heatmap_info$typeLabel=="Severe",]
heatmap_info_2 <- heatmap_info[heatmap_info$typeLabel=="Non_Severe",]
heatmap_info_all <- rbind(heatmap_info_1, heatmap_info_2)
t_heatmap_info_all <- data.frame(t(heatmap_info_all))
write.csv(t_heatmap_info_all,"heatmap_info_caixue_right_20200531.csv")
