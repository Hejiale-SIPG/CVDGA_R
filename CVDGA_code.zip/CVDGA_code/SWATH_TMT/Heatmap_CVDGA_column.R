library(pheatmap)
library(RColorBrewer)

features_t <- read.csv("fin_matirx_t_rf.csv", stringsAsFactors = F)
features_v <- read.csv("fin_matirx_v_rf.csv", stringsAsFactors = F)
features_t_1 <- features_t[,-3]
allpro1 <- rbind(features_t_1, features_v)  
allpro1 <- allpro1[,-1]
allpro1 <- allpro1[,-2]
allpro2 <- data.frame(t(allpro1))
names(allpro2) <- allpro2[1,]
allpro2 <- allpro2[-1,]
write.csv(allpro2, "heatmap_input.csv")
##########################################

allpro1 <- read.csv("heatmap_info_caixue_right_20200531.csv", stringsAsFactors = F, row.names = 1)
allpro3 <- read.csv("heatmap_info_caixue_right_20200531.csv", stringsAsFactors = F, row.names = 1)
allpro1 <- allpro1[-1,]
allpro3 <- allpro3[1,]
identical(names(allpro1), names(allpro3))

matall1<-matrix(0,nrow=nrow(allpro1),ncol=ncol(allpro1))


for(i in 1:nrow(allpro1)){
  for(j in 1:ncol(allpro1)){
    matall1[i,j]<-as.numeric(allpro1[i,j])
  }
}
colnames(matall1)<-colnames(allpro1)
rownames(matall1)<-rownames(allpro1)




annotation_col <- allpro3[1,]
annotation_col <- data.frame(
  typeLabel = factor(annotation_col[1,])
)



pheatmap(matall1, color = c(brewer.pal(11,"RdYlBu")[9:7],"azure1",brewer.pal(11,"RdYlBu")[4:1]), 
         fontsize_col = 8,
         scale = "row",cluster_cols = F, cluster_rows = T,show_rownames = T, show_colnames = F,
         legend = TRUE,  annotation_col = annotation_col, #angle_col = "45",
         gaps_col = c(33),
         gaps_row = c(9,11),
         filename = "heatmap_train_20200531.pdf",
         main = "train cohort",width=10,height=10
)

