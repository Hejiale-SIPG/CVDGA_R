library(dplyr)



uniAll<-read.csv("uniprot-filtered-organism__Homo+sapiens+(Human)+(9606)_.csv",stringsAsFactors = F)
promart <- read.csv("CVDSSB_proteins_2020426_origin_data_caixue.csv", stringsAsFactors = F,row.names = 1)
complex_table <- read.csv("allComplexes.csv", stringsAsFactors = F)
protein_n <- read.csv("protein_name_20200527.csv", stringsAsFactors = F)
promart[is.na(promart)]<-min(promart,na.rm=T)*0.8
selInd_2 <- vector()
selInd_2 <- c(selInd_2,which(grepl("^1/sp",row.names(promart))))
protMat_de <- promart[selInd_2,]
protMat_de_z <- data.frame(sapply(protMat_de,scale))
row.names(protMat_de_z) <- row.names(protMat_de)

####### find complex #############
df_complex <- vector()
for(i in 1:nrow(protein_n)){
  protSel <- protein_n$Uniport_ID[i]
  selInd <- vector()
  for(j in 1:length(complex_table)){
    # protMat_deSel<-protMat_de[ which(grepl(protSel[i],row.names(protMat_de))),]
    selInd<-c(selInd,which(grepl(protSel[j],complex_table$subunits.UniProt.IDs.)))
  }
  if (length(selInd) > 0){
    complex_table_deSel <- complex_table[selInd,]
    df_complex <- rbind(df_complex, complex_table_deSel)
    print(i)
  }
  }
df_complex <- distinct(df_complex)
#######################################

df_GO <- data.frame(matrix(NA,nrow=nrow(df_complex), ncol=ncol(protMat_de_z)), stringsAsFactors = F)
row.names(df_GO) <- df_complex$ComplexID
names(df_GO)<-names(protMat_de_z)


######## calculate complex ########

for(i in 1:nrow(df_complex)){
  prot_sp <- unlist(strsplit(df_complex$subunits.UniProt.IDs.[i],";"))
  selInd<-vector()
  for(j in 1:length(prot_sp)){
    selInd<-c(selInd,which(grepl(prot_sp[j],row.names(protMat_de_z))))
  }
  if (length(selInd) > 1) {
  protMat_deSel_z<-protMat_de_z[selInd,]
  protMat_deSel_z <- distinct(protMat_deSel_z)
  df_GO[i,]<-apply(protMat_deSel_z,2,sum,na.rm=T) #sum by row
  protMat_name <- protMat_de_z[selInd,]
  protMat_row_name <- unlist(row.names(protMat_name))
  gene_id_c <- vector()
  for (n in 1:length(protMat_row_name)){
  protein_entry <-  unlist(strsplit(protMat_row_name[n],"\\|"))[2]
  s_uniportID <- uniAll$Entry[which(uniAll$Entry==protein_entry)]
  gene_names <- paste(unique(uniAll$Gene[which(uniAll$Entry == unique(s_uniportID))]),collapse = ";")
  gene_id_c[n] <- gene_names
  gene_id_all <- paste(gene_id_c,collapse = ",")
  }
  row.names(df_GO)[i] <- paste(df_complex$ComplexName[i],"(",gene_id_all,")")
  print(i)
  }
  
}
# df_GOMatSel<-df_GO[apply((df_GO)=="NA",1,sum)!=ncol(df_GO),]
df_GOMatSel<-df_GO[apply(is.na(df_GO),1,sum)!=ncol(df_GO),]
write.csv(df_GOMatSel, "complex_column_20200528.csv")
df

##################################################
protRatioNames<-vector();m=1
for(i in 1:nrow(readin)){
  prot_sp <- unlist(strsplit(readin$Protein[i],","))
  if (length(prot_sp) > 1) {
    comb<-combn(1:length(prot_sp),2)
    for(j in 1:ncol(comb))  {
      protRatioNames[m]<-paste(prot_sp[comb[,j]],collapse = "/")
      m<-m+1
    }
  }
  print(i)
}
protRatioNames <- unique(protRatioNames)

# row.names(promart) <- promart$ID
  promart_ma <- protMat_de
# promart_ma_NoNA<-promart_ma
# promart_ma_NoNA[promart_ma_NoNA==0]<-NA
# promart_ma_NoNA[is.na(promart_ma_NoNA)]<-min(promart_ma_NoNA, na.rm=T)

protRatioMat<-data.frame(matrix(0,nrow=length(protRatioNames),ncol=ncol(promart_ma)))
row.names(protRatioMat)<-protRatioNames
colnames(protRatioMat)<-colnames(promart_ma)
protRatioMat_1 <- vector()
for(i in 1:nrow(protRatioMat)){
  selProt<-unlist(strsplit(row.names(protRatioMat)[i],"/"))
  selInd<-vector()
  for(m in 1:length(selProt)){
    # protMat_deSel<-protMat_de[ which(grepl(protSel[i],row.names(protMat_de))),]
    selInd<-c(selInd,which(grepl(selProt[m],row.names(promart_ma))))
  }
  protRatioMat_deSel <- promart_ma[selInd,] 
  protMat_deSel_2_fi <- log2(as.numeric(protRatioMat_deSel[1,]))-log2(as.numeric(protRatioMat_deSel[2,]))
  protRatioMat_1[i]<-paste(protMat_deSel_2_fi,collapse = ";") #sum by row
  print(i)
}


for(i in 1:nrow(protRatioMat)){
  protRatioMat[i,]<-unlist(strsplit(protRatioMat_1[i],";"))
  print(i)
  
}
write.csv(protRatioMat,"ratio_column_20200528.csv",row.names = T)

protRatioMatSel<-protRatioMat[apply((protRatioMat)=="NA",1,sum)!=ncol(protRatioMat),]
write.csv(protRatioMatSel,"ratio_MatSel_column_20200528.csv",row.names = T)

# pathways <- read.csv("pathway_matrix_20200519.csv", stringsAsFactors = F, row.names = 1)
pathway_name_d <- read.csv("bioplex_differential_protein_pathway.csv", stringsAsFactors = F, row.names = 1)
df_GO_p <- data.frame(matrix(NA,nrow=nrow(pathway_name_d), ncol=ncol(protMat_de_z)), stringsAsFactors = F)
row.names(df_GO_p) <- c(as.matrix((pathway_name_d[, 2])))
names(df_GO_p)<-c(as.matrix(names(protMat_de)))
df_GO_p_1 <- data.frame(matrix(NA,nrow=nrow(pathway_name_d),ncol=1),stringsAsFactors = F)
for(m in 1:nrow(pathway_name_d)){
  protSel<-unlist(strsplit(pathway_name_d$intersections[m],","))# text to column by ","
  selInd<-vector()
  for(i in 1:length(protSel)){
    # protMat_deSel<-protMat_de[ which(grepl(protSel[i],row.names(protMat_de))),]
    selInd<-c(selInd,which(grepl(protSel[i],row.names(protMat_de_z))))
  }
  protMat_deSel_z<-protMat_de_z[selInd,]
  protMat_deSel_z <- distinct(protMat_deSel_z)
  df_GO_p[m,]<-apply(protMat_deSel_z,2,sum,na.rm=T) #sum by row
  pathway_name <- protMat_de_z[selInd,]
  protMat_row_name <- unlist(unique(row.names(pathway_name)))
  gene_id_z <- vector()
  for (n in 1:length(protMat_row_name)){
    protein_entry <-  unlist(strsplit(protMat_row_name[n],"\\|"))[2]
    s_uniportID <- uniAll$Entry[which(uniAll$Entry==protein_entry)]
    gene_names <- paste(unique(uniAll$Gene[which(uniAll$Entry == unique(s_uniportID))]),collapse = ";")
    gene_id_z[n] <- gene_names
  }
  gene_id_z <- unique(gene_id_z)
  gene_id_all_p <- paste(gene_id_z,collapse = ",")
  row.names(df_GO_p)[m] <- paste(pathway_name_d$term_name[m],"(",length(protMat_row_name),")")
  row.names(df_GO_p_1)[m] <- paste(pathway_name_d$term_name[m],"(",length(protMat_row_name),")")
  df_GO_p_1[m,1] <- gene_id_all_p
  print(m)
}

all_column <- rbind(df_GOMatSel,protRatioMatSel,df_GO_p,protMat_de)

write.csv(all_column, "all_column_20200530.csv")
##############################################################
uniAll<-read.csv("uniprot-filtered-organism__Homo+sapiens+(Human)+(9606)_.csv",stringsAsFactors = F)
all_column <- read.csv("all_column_20200530.csv",stringsAsFactors = F)
# for (i in 1:16){
#   complex_ID <- all_column$X[i]
#   complex_names <- vector()
#   s_c_name <- complex_table[complex_table$ComplexID==complex_ID,]
#   complex_names <- s_c_name$ComplexName
#   all_column$X[i] <- complex_names
# }

for (i in 17:41){
  uniportID <- unlist(strsplit(all_column$X[i],"/"))
  gene_names <- vector()
  for(m in 1:length(uniportID)){
    s_uniportID <- uniAll$Entry[which(uniAll$Entry==uniportID[m])]
    gene_names[m] <- paste(unique(uniAll$Gene[which(uniAll$Entry == unique(s_uniportID))]),collapse = ";")
  }
  all_column$X[i]<-paste(gene_names,collapse = "/")
}


UniProtIDs<-vector()
for(i in 100:nrow(all_column)){
  UniProtIDs[i]<-unlist(strsplit(all_column$X[i],"\\|"))[2]
  s_uniportID <- uniAll$Entry[which(uniAll$Entry==UniProtIDs[i])]
  gene_names <- paste(unique(uniAll$Gene[which(uniAll$Entry == unique(s_uniportID))]),collapse = ";")
  all_column$X[i] <-gene_names
}
all_column <- all_column[c(-164,-234:-238),]
row.names(all_column)<-all_column$X
all_column <- all_column[,-1]
write.csv(all_column,"all_column_20200530_v.csv")



####################################################################### umap
library(umap)

liuwei <- read.csv("protRatioMatSel_ab.csv", stringsAsFactors = F)

umapIn <- read.csv("protRatioMatSel_ab_all_noNA.csv", stringsAsFactors = F,row.names = 1)

u1<-umap(t(umapIn))

plot(u1$layout[,1],u1$layout[,2],col=as.factor(liuwei$batchId))


log2()

####################################################################
promart_deNA<-apply(is.na(protMat_de),1,sum)/ncol(protMat_de)
mean(promart_deNA)

