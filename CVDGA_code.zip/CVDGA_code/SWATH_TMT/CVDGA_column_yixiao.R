library(dplyr)




promart <- read.csv("proMatTrVl_FZ20200413_yixiao.csv", stringsAsFactors = F,row.names = 1)
complex_table <- read.csv("allComplexes.csv", stringsAsFactors = F)
protein_n <- read.csv("protein_name_20200527.csv", stringsAsFactors = F)
promart[is.na(promart)]<-min(promart,na.rm=T)*0.8
protMat_de_z <- data.frame(sapply(promart,scale))
row.names(protMat_de_z) <- row.names(promart)




####### find complex #############
df_complex <- vector()
for(i in 1:nrow(protein_n)){
  protSel <- protein_n$Uniport_ID[i]
  selInd <- vector()
  for(j in 1:length(complex_table)){
    # protMat_deSel<-protMat_de[ which(grepl(protSel[i],row.names(protMat_de))),]
    selInd<-c(selInd,which(grepl(protSel[j],complex_table$subunits.UniProt.IDs.)))
  }
  if (length(selInd) > 0){
    complex_table_deSel <- complex_table[selInd,]
    df_complex <- rbind(df_complex, complex_table_deSel)
    print(i)
  }
}
df_complex <- distinct(df_complex)

df_GO <- data.frame(matrix(NA,nrow=nrow(df_complex), ncol=ncol(protMat_de_z)), stringsAsFactors = F)
row.names(df_GO) <- df_complex$ComplexID
names(df_GO)<-names(protMat_de_z)

complex1 <- read.csv("complex_column_20200528.csv",stringsAsFactors = F,row.names = 1)
######## calculate complex ########

for(i in 1:nrow(df_complex)){
  prot_sp <- unlist(strsplit(df_complex$subunits.UniProt.IDs.[i],";"))
  selInd<-vector()
  for(j in 1:length(prot_sp)){
    # protMat_deSel<-protMat_de[ which(grepl(protSel[i],row.names(protMat_de))),]
    selInd<-c(selInd,which(grepl(prot_sp[j],row.names(protMat_de_z))))
  }
  if (length(selInd) > 1) {
  protMat_deSel_z<-protMat_de_z[selInd,]
  protMat_deSel_z <- distinct(protMat_deSel_z)
  df_GO[i,]<-apply(protMat_deSel_z,2,sum,na.rm=T) #sum by row
  print(i)
  }
  
}
# df_GOMatSel<-df_GO[apply((df_GO)=="NA",1,sum)!=ncol(df_GO),]
df_GOMatSel<-df_GO[apply(is.na(df_GO),1,sum)!=ncol(df_GO),]
write.csv(df_GOMatSel, "complex_column_20200529_yixiao.csv")

##################################################
protRatioNames<-vector();m=1
for(i in 1:nrow(df_complex)){
  prot_sp <- unlist(strsplit(df_complex$subunits.Gene.name.[i],";"))
  if (length(prot_sp) > 1) {
    comb<-combn(1:length(prot_sp),2)
    for(j in 1:ncol(comb))  {
      protRatioNames[m]<-paste(prot_sp[comb[,j]],collapse = "/")
      m<-m+1
    }
  }
  print(i)
}
protRatioNames <- unique(protRatioNames)

# row.names(promart) <- promart$ID
  promart_ma <- promart
# promart_ma_NoNA<-promart_ma
# promart_ma_NoNA[promart_ma_NoNA==0]<-NA
# promart_ma_NoNA[is.na(promart_ma_NoNA)]<-min(promart_ma_NoNA, na.rm=T)

protRatioMat<-data.frame(matrix(0,nrow=length(protRatioNames),ncol=ncol(promart_ma)))
row.names(protRatioMat)<-protRatioNames
colnames(protRatioMat)<-colnames(promart_ma)
protRatioMat_1 <- vector()
for(i in 1:nrow(protRatioMat)){
  selProt<-unlist(strsplit(row.names(protRatioMat)[i],"/"))
  selInd<-vector()
  for(m in 1:length(selProt)){
    # protMat_deSel<-protMat_de[ which(grepl(protSel[i],row.names(protMat_de))),]
    selInd<-c(selInd,which(grepl(selProt[m],row.names(promart_ma))))
  }
  protRatioMat_deSel <- promart_ma[selInd,] 
  protMat_deSel_2_fi <- log2(as.numeric(protRatioMat_deSel[1,]))-log2(as.numeric(protRatioMat_deSel[2,]))
  protRatioMat_1[i]<-paste(protMat_deSel_2_fi,collapse = ";") #sum by row
  print(i)
}


for(i in 1:nrow(protRatioMat)){
  protRatioMat[i,]<-unlist(strsplit(protRatioMat_1[i],";"))
  print(i)
  
}
#write.csv(protRatioMat,"ratio_column_20200528.csv",row.names = T)

protRatioMatSel<-protRatioMat[apply((protRatioMat)=="NA",1,sum)!=ncol(protRatioMat),]
#write.csv(protRatioMatSel,"ratio_MatSel_column_20200528.csv",row.names = T)

pathways <- read.csv("pathway_matrix_20200520_yixiao.csv", stringsAsFactors = F, row.names = 1)

all_column <- rbind(df_GOMatSel,protRatioMatSel,pathways,promart)

write.csv(all_column, "all_column_yixiao_20200529.csv")
##############################################################
uniAll<-read.csv("uniprot-filtered-organism__Homo+sapiens+(Human)+(9606)_.csv",stringsAsFactors = F)
all_column <- read.csv("all_column_yixiao_20200529.csv",stringsAsFactors = F)
for (i in 1:41){
  complex_ID <- all_column$X[i]
  complex_names <- vector()
  s_c_name <- complex_table[complex_table$ComplexID==complex_ID,]
  complex_names <- s_c_name$ComplexName
  all_column$X[i] <- complex_names
}

for (i in 42:116){
  uniportID <- unlist(strsplit(all_column$X[i],"/"))
  gene_names <- vector()
  for(m in 1:length(uniportID)){
    s_uniportID <- uniAll$Entry[which(uniAll$Entry==uniportID[m])]
    gene_names[m] <- paste(unique(uniAll$Gene[which(uniAll$Entry == unique(s_uniportID))]),collapse = ";")
  }
  all_column$X[i]<-paste(gene_names,collapse = "/")
}


UniProtIDs<-vector()
for(i in 175:nrow(all_column)){
  UniProtIDs[i]<-all_column$X[i]
  s_uniportID <- uniAll$Entry[which(uniAll$Entry==UniProtIDs[i])]
  gene_names <- paste(unique(uniAll$Gene[which(uniAll$Entry == unique(s_uniportID))]),collapse = ";")
  all_column$X[i] <-gene_names
}
all_column <- all_column[all_column$X!="",]

row.names(all_column)<-all_column$X
all_column <- all_column[,-1]
write.csv(all_column,"all_column_20200529_yixiao.csv")



####################################################################### umap
library(umap)

liuwei <- read.csv("protRatioMatSel_ab.csv", stringsAsFactors = F)

umapIn <- read.csv("protRatioMatSel_ab_all_noNA.csv", stringsAsFactors = F,row.names = 1)

u1<-umap(t(umapIn))

plot(u1$layout[,1],u1$layout[,2],col=as.factor(liuwei$batchId))


log2()

##########################################################################
promartNA<-apply(is.na(promart),1,sum)/ncol(promart)
mean(promart_deNA)