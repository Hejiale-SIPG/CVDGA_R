b1 <- read.csv("density_info_caixue_right_20200531_AGT_C3.csv", stringsAsFactors = F, row.names = 1,header = F)

matall1<-matrix(0,nrow=nrow(b1),ncol=ncol(b1))
for(i in 1:nrow(b1)){
  for(j in 1:ncol(b1)){
    matall1[i,j]<-as.numeric(b1[i,j])
  }
}
colnames(matall1)<-colnames(b1)
rownames(matall1)<-rownames(b1)
matall2 <- log2(matall1)

pdf("AGT_C3_ratio_density_log2_20200523_1.pdf", width = 10, height = 10)
plot(density(matall1[1,],na.rm = T),col="#56B4E9")
lines(density(matall1[2,],na.rm = T), col="#D55E00")
dev.off()
