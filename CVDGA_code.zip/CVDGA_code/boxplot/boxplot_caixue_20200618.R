info_boxplot<-read.csv("heatmap_info_caixue_right_20200531.csv",stringsAsFactors = F,row.names = 1)
proT_1<-info_boxplot[, 1:33]
proT_2<-proT_1[-1,]
proN_1<-info_boxplot[, 34:54]
proN_2<-proN_1[-1,]

proN<-matrix(0,nrow=nrow(proN_2),ncol=ncol(proN_2))
for(i in 1:nrow(proN_2)){
  for(j in 1:ncol(proN_2)){
    proN[i,j]<-as.numeric(proN_2[i,j])
  }
}
colnames(proN)<-colnames(proN_2)
rownames(proN)<-rownames(proN_2)

proT<-matrix(0,nrow=nrow(proT_2),ncol=ncol(proT_2))
for(i in 1:nrow(proT_2)){
  for(j in 1:ncol(proT_2)){
    proT[i,j]<-as.numeric(proT_2[i,j])
  }
}
colnames(proT)<-colnames(proT_2)
rownames(proT)<-rownames(proT_2)

pdf("boxplot_top25_features_col_0.pdf",width = 10, height = 10)
par(mfrow=c(3,3))
for(i in 1:nrow(proT)){
boxplot(list(proT[i,],proN[i,]),names=c("Non_Severe","Severe"),main=paste(row.names(proT)[i]),
        pars = list(boxwex = 0.8, staplewex = 0.5, outwex = 0.8),cex.axis=1.5,col = 0)
stripchart(list(proT[i,],proN[i,]),vertical = T,add=T,pch=19,jitter = 0.2,method = "jitter",cex=1.2
           ,col=c("#A5C0DF","#EA8C8C"))
text(paste0("p < ", round(t.test(proT[i,])$p.value, 3)))
}
dev.off()


library(ggpubr)
info_boxplot_t<-data.frame(t(info_boxplot))
names(info_boxplot_t)<-row.names(info_boxplot)

plot.boxplot1 <- function(data,type,title){
  p <- ggboxplot(data, x="typeLabel",y="abundance", color =type,
                 palette = c("#5F80B4","#E29827"),
                 add = "jitter",title =title)
  my_comparisons <- list( c("Severe", "Non_Severe") )
  q <- p+stat_compare_means(method = "t.test",comparisons = my_comparisons)# +#?????????????????????
  # stat_compare_means(label.y = 50)
  #ggsave(paste0(filename, ".pdf"),plot=q,width=8,height=8)
  print(q)
}

pdf("top25_features_20200619_pvalue.pdf",width = 10, height = 10)
par(mfrow=c(3,3))
for(i in 1:(ncol(info_boxplot_t)-1)){
a<-info_boxplot_t[,c(1,(i+1))]
a[,2]<-as.numeric(a[,2])
b<-a
names(a)<-c("typeLabel","abundance")
plot.boxplot1(a,"typeLabel",names(b)[2])

print(i)
}
dev.off()

